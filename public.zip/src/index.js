import React,{Component} from "react";
import ReactDOM from "react-dom"
import "jquery";
import "popper.js/dist/popper";
import "bootstrap/dist/js/bootstrap";
import "bootstrap/dist/css/bootstrap.css";
import NavigationBar from "./NavigationBar";
import MainContent from "./MainContent";

ReactDOM.render(<NavigationBar></NavigationBar>,document.getElementById("root"));