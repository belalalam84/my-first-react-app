import React, { Component } from "react";
import { Route } from "react-router-dom";
import { Link } from "react-router-dom";

class NavigationBar extends Component{
    render(){
        return(
              <React.Fragment>
                <nav className="navbar navbar-expand-lg navbar-light bg-light navAlign">
                    <a className="navbar-brand" href="/">HostBooks</a>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="/#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav mr-auto">
                            <li className="nav-item">
                                <a className="nav-link" href="index">Home</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="./abutus">About Us</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="/#">Services</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="/#">Contact</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </React.Fragment>
        );
    }
}

export default NavigationBar;