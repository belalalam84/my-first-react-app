import React,{Component} from "react";

export default class MainContent extends Component{
    render(){
        return 
        <div className="red">Hello Main content is calling</div>;
       
    }
}