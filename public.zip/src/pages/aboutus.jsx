import React, { Component } from "react";
class aboutus extends Component{
    render(){
        return(
              <React.Fragment>
                <div>about us</div>
            </React.Fragment>
        );
    }
}

export default aboutus;