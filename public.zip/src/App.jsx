import React,{Component} from "react";
import NavigationBar from "./NavigationBar";
import MainContent from "./MainContent";
import { Router } from "react-router-dom";

export default class App extends Component
{
render()
 {
    return (
        // <React.Fragment>
        //     <NavigationBar></NavigationBar>
        //     <MainContent></MainContent>
        // </React.Fragment>
        <Router>
            <switch>
            <NavigationBar></NavigationBar>
            <MainContent></MainContent>
            </switch>
        </Router>
    );
 }
}